
DROP DATABASE IF EXISTS bookstore_db;
CREATE DATABASE bookstore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookstore_db;

-- =====================================================================
-- CREATE TABLES
-- =====================================================================

CREATE TABLE authors (
    author_id   INT AUTO_INCREMENT PRIMARY KEY,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    biography   TEXT,
    nationality VARCHAR(50),
    birth_date  DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE publishers (
    publisher_id INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL UNIQUE,
    address      VARCHAR(200),
    city         VARCHAR(80),
    country      VARCHAR(60),
    website      VARCHAR(200)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE categories (
    category_id        INT AUTO_INCREMENT PRIMARY KEY,
    name               VARCHAR(80) NOT NULL UNIQUE,
    description        TEXT,
    parent_category_id INT NULL,
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_category_id) REFERENCES categories(category_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE books (
    book_id          INT AUTO_INCREMENT PRIMARY KEY,
    isbn             CHAR(13)      NOT NULL UNIQUE,
    title            VARCHAR(200)  NOT NULL,
    publisher_id     INT           NOT NULL,
    description      TEXT,
    price            DECIMAL(8,2)  NOT NULL,
    stock            INT           NOT NULL DEFAULT 0,
    publication_date DATE,
    pages            INT,
    language         VARCHAR(30)   NOT NULL DEFAULT 'English',
    created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_books_price CHECK (price > 0),
    CONSTRAINT chk_books_stock CHECK (stock >= 0),
    CONSTRAINT chk_books_pages CHECK (pages IS NULL OR pages > 0),
    CONSTRAINT fk_books_publisher
        FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Junction table: books <-> authors (M:N)
CREATE TABLE book_authors (
    book_id      INT NOT NULL,
    author_id    INT NOT NULL,
    author_order TINYINT NOT NULL DEFAULT 1,
    PRIMARY KEY (book_id, author_id),
    CONSTRAINT chk_book_authors_order CHECK (author_order >= 1),
    CONSTRAINT fk_ba_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ba_author
        FOREIGN KEY (author_id) REFERENCES authors(author_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Junction table: books <-> categories (M:N)
CREATE TABLE book_categories (
    book_id     INT NOT NULL,
    category_id INT NOT NULL,
    PRIMARY KEY (book_id, category_id),
    CONSTRAINT fk_bc_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bc_category
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE customers (
    customer_id   INT AUTO_INCREMENT PRIMARY KEY,
    first_name    VARCHAR(50)  NOT NULL,
    last_name     VARCHAR(50)  NOT NULL,
    email         VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone         VARCHAR(20),
    street        VARCHAR(200),
    city          VARCHAR(80),
    postal_code   VARCHAR(20),
    country       VARCHAR(60),
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE orders (
    order_id             INT AUTO_INCREMENT PRIMARY KEY,
    customer_id          INT NOT NULL,
    order_date           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status               ENUM('pending','paid','shipped','delivered','cancelled')
                         NOT NULL DEFAULT 'pending',
    total_amount         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    shipping_street      VARCHAR(200) NOT NULL,
    shipping_city        VARCHAR(80)  NOT NULL,
    shipping_postal_code VARCHAR(20),
    shipping_country     VARCHAR(60)  NOT NULL,
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    book_id       INT NOT NULL,
    quantity      INT NOT NULL DEFAULT 1,
    unit_price    DECIMAL(8,2) NOT NULL,
    subtotal      DECIMAL(10,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    UNIQUE KEY uq_order_book (order_id, book_id),
    CONSTRAINT chk_oi_quantity CHECK (quantity > 0),
    CONSTRAINT chk_oi_price    CHECK (unit_price > 0),
    CONSTRAINT fk_oi_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_oi_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reviews (
    review_id   INT AUTO_INCREMENT PRIMARY KEY,
    book_id     INT NOT NULL,
    customer_id INT NOT NULL,
    rating      TINYINT NOT NULL,
    comment     TEXT,
    review_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_review_customer_book (customer_id, book_id),
    CONSTRAINT chk_reviews_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_reviews_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================================
-- SAMPLE DATA
-- =====================================================================

-- 4 publishers
INSERT INTO publishers (name, address, city, country, website) VALUES
('Penguin Random House', '1745 Broadway',            'New York', 'USA', 'https://www.penguinrandomhouse.com'),
('HarperCollins',        '195 Broadway',             'New York', 'USA', 'https://www.harpercollins.com'),
('O''Reilly Media',      '1005 Gravenstein Hwy N',   'Sebastopol','USA', 'https://www.oreilly.com'),
('Bloomsbury',           '50 Bedford Square',        'London',   'UK',  'https://www.bloomsbury.com');

-- 9 authors (>= 6)
INSERT INTO authors (first_name, last_name, biography, nationality, birth_date) VALUES
('George',  'Orwell',   'English novelist and essayist known for dystopian fiction and political writing.', 'British',  '1903-06-25'),
('Frank',   'Herbert',  'American science fiction author best known for the Dune series.',                  'American', '1920-10-08'),
('J.R.R.',  'Tolkien',  'English writer and philologist, author of The Hobbit and The Lord of the Rings.',  'British',  '1892-01-03'),
('J.K.',    'Rowling',  'British author of the Harry Potter fantasy series.',                              'British',  '1965-07-31'),
('Martin',  'Kleppmann','Researcher and author focusing on distributed systems and databases.',            'British',  '1985-01-01'),
('Yuval Noah','Harari', 'Israeli historian and professor at the Hebrew University of Jerusalem.',          'Israeli',  '1976-02-24'),
('Alan',    'Beaulieu', 'Author and consultant with long experience teaching and using SQL.',              'American', '1965-03-12'),
('Terry',   'Pratchett','English author of the Discworld fantasy series.',                                 'British',  '1948-04-28'),
('Neil',    'Gaiman',   'English author of novels, comics and screenplays.',                               'British',  '1960-11-10');

-- 5 categories (Science Fiction and History are sub-categories)
INSERT INTO categories (name, description, parent_category_id) VALUES
('Fiction',         'Imaginative narrative works including novels and stories.', NULL),
('Science Fiction', 'Fiction based on futuristic science and technology.',       1),
('Non-Fiction',     'Factual books based on real events and information.',       NULL),
('Technology',      'Books about computing, databases and software engineering.',NULL),
('History',         'Books about past events and human civilization.',           3);

-- 8 books
INSERT INTO books (isbn, title, publisher_id, description, price, stock, publication_date, pages, language) VALUES
('9780451524935', '1984',                                       1, 'A dystopian novel about totalitarian surveillance.',              9.99,  50, '1949-06-08', 328, 'English'),
('9780441013593', 'Dune',                                       1, 'Epic science fiction saga on the desert planet Arrakis.',        11.99, 40, '1965-08-01', 688, 'English'),
('9780547928227', 'The Hobbit',                                 2, 'Bilbo Baggins joins a quest to reclaim a dwarf kingdom.',        12.50, 35, '1937-09-21', 310, 'English'),
('9781408855652', 'Harry Potter and the Philosopher''s Stone',  4, 'A young boy discovers he is a wizard.',                          10.99, 60, '1997-06-26', 336, 'English'),
('9781449373320', 'Designing Data-Intensive Applications',      3, 'Principles behind reliable, scalable data systems.',             45.99, 25, '2017-03-16', 616, 'English'),
('9780062316110', 'Sapiens: A Brief History of Humankind',      2, 'A history of the human species from the Stone Age to today.',    18.99, 30, '2015-02-10', 464, 'English'),
('9780596520830', 'Learning SQL',                               3, 'Practical introduction to SQL for beginners.',                   34.99, 20, '2009-04-11', 338, 'English'),
('9780060853983', 'Good Omens',                                 2, 'An angel and a demon try to prevent the apocalypse.',            14.99, 45, '1990-05-01', 400, 'English');

-- book_authors (M:N)
INSERT INTO book_authors (book_id, author_id, author_order) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(8, 9, 2);

-- book_categories (M:N)
INSERT INTO book_categories (book_id, category_id) VALUES
(1, 1), (1, 2),
(2, 2),
(3, 1),
(4, 1),
(5, 4),
(6, 3), (6, 5),
(7, 4),
(8, 1);

-- 5 customers (password_hash = sample bcrypt-style hashes)
INSERT INTO customers (first_name, last_name, email, password_hash, phone, street, city, postal_code, country) VALUES
('Nguyen', 'An',   'an.nguyen@example.com',   '$2b$12$K1a9vQ3mZpX7LrT2uYhE5eN8wQd4sB6cJ0fGtVxRzAoIlMkPnUyHe', '0901234567', '12 Hang Bai',        'Hanoi',        '100000', 'Vietnam'),
('Tran',   'Binh', 'binh.tran@example.com',   '$2b$12$P7d2wRz5Xc8NqL1vHeT4yOu9sJ3gKb6aFm0iWtYxCnEoUlSdQrVhZ', '0912345678', '45 Le Loi',          'Ho Chi Minh City','700000','Vietnam'),
('Le',     'Chi',  'chi.le@example.com',      '$2b$12$Z4n8tYb1Qe6VwK3xRc9uHdO2sLg5jPa7FmI0yTzXoNqEvAlCkBrUw', '0923456789', '8 Bach Dang',         'Da Nang',      '550000', 'Vietnam'),
('Pham',   'Duc',  'duc.pham@example.com',    '$2b$12$H6k3xLw9Zp2NcT5vQe8yRu1sOj4gBa7FdM0iYtXzCnEoUlWqVrKhA', '0934567890', '27 Tran Phu',         'Hue',          '530000', 'Vietnam'),
('Hoang',  'Em',   'em.hoang@example.com',    '$2b$12$B9r5tNy2Wq7XcL4vKe1uHdO6sPj3gZa8FmI0yTzVoCnEkUlSxQeRw', '0945678901', '99 Nguyen Hue',       'Can Tho',      '900000', 'Vietnam');

-- 6 orders (total_amount = sum of subtotals of its items)
INSERT INTO orders (customer_id, order_date, status, total_amount, shipping_street, shipping_city, shipping_postal_code, shipping_country) VALUES
(1, '2026-09-02 10:15:00', 'delivered', 33.97, '12 Hang Bai',   'Hanoi',            '100000', 'Vietnam'),
(2, '2026-09-10 14:30:00', 'delivered', 80.98, '45 Le Loi',     'Ho Chi Minh City', '700000', 'Vietnam'),
(3, '2026-09-18 09:05:00', 'shipped',   34.48, '8 Bach Dang',   'Da Nang',          '550000', 'Vietnam'),
(1, '2026-10-05 20:45:00', 'pending',   33.98, '12 Hang Bai',   'Hanoi',            '100000', 'Vietnam'),
(4, '2026-10-08 11:20:00', 'delivered', 36.97, '27 Tran Phu',   'Hue',              '530000', 'Vietnam'),
(5, '2026-10-12 16:00:00', 'cancelled', 64.98, '99 Nguyen Hue', 'Can Tho',          '900000', 'Vietnam');

-- 13 order items (subtotal is generated automatically)
INSERT INTO order_items (order_id, book_id, quantity, unit_price) VALUES
(1, 1, 1,  9.99),
(1, 2, 2, 11.99),
(2, 5, 1, 45.99),
(2, 7, 1, 34.99),
(3, 4, 2, 10.99),
(3, 3, 1, 12.50),
(4, 6, 1, 18.99),
(4, 8, 1, 14.99),
(5, 2, 1, 11.99),
(5, 8, 1, 14.99),
(5, 1, 1,  9.99),
(6, 5, 1, 45.99),
(6, 6, 1, 18.99);

-- 10 reviews (one review per customer per book)
INSERT INTO reviews (book_id, customer_id, rating, comment, review_date) VALUES
(1, 1, 5, 'A chilling and still very relevant classic.',                  '2026-09-12 08:00:00'),
(2, 1, 4, 'Dense worldbuilding, slow start but worth it.',                '2026-09-14 19:30:00'),
(2, 4, 5, 'Best science fiction novel I have ever read.',                 '2026-10-15 21:10:00'),
(5, 2, 5, 'Essential reading for any backend engineer.',                  '2026-09-25 13:45:00'),
(7, 2, 4, 'Clear explanations and good exercises for SQL beginners.',     '2026-09-27 10:20:00'),
(4, 3, 5, 'Magical, my kids loved it.',                                   '2026-09-28 18:00:00'),
(3, 3, 4, 'Charming adventure, a bit short.',                             '2026-09-29 20:15:00'),
(8, 4, 4, 'Hilarious and clever.',                                        '2026-10-16 09:40:00'),
(1, 4, 3, 'Good story but quite bleak.',                                  '2026-10-16 09:55:00'),
(6, 3, 5, 'Fascinating overview of human history.',                       '2026-10-01 12:00:00');

-- =====================================================================
-- Quick sanity check (optional)
-- =====================================================================
-- SELECT o.order_id, o.total_amount, SUM(oi.subtotal) AS items_total
-- FROM orders o JOIN order_items oi ON oi.order_id = o.order_id
-- GROUP BY o.order_id, o.total_amount;
